Images are taken from the Middlebury stereo and flow databases at http://vision.middlebury.edu/
