Created from data made available by Peter Gehler at http://files.is.tue.mpg.de/pgehler/projects/color/index.html
