This data was created from images captured at Adobe Systems. See https://github.com/ayanc/rgbps/tree/master/data for attribution and license.
