The problem 5 images are taken from the KITTI stereo dataset available at http://www.cvlibs.net/datasets/kitti/eval_stereo_flow.php?benchmark=stereo
